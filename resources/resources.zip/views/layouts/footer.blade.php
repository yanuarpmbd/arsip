
<div class="footer">
    <div class="pull-right">
        <strong>ARSIP</strong> DPMPTSP
    </div>
    <div>
        <strong>Copyright</strong> DPMPTSP Prov Jateng &copy; 2019
    </div>
</div>
