@extends('master.master')

@section('content')

    @include('yanjin.layouts.search_result')

@endsection
