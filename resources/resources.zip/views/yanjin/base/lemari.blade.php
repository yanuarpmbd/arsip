@extends('master.master_')
@section('content')
    @include('yanjin.content.form_lemari')
    @include('yanjin.content.data_lemari')
@endsection
