@extends('master.master_')
@section('content')
    @include('yanjin.content.form_pj')
    @include('yanjin.content.data_pj')
@endsection
