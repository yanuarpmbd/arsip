@extends('master.master_')
@section('content')

    @include('yanjin.content.form_sektor')
    @include('yanjin.content.data_sektor')
@endsection
