@extends('master.master_')
@section('content')

    @include('yanjin.content.edit_izin')
@endsection
