@extends('master.master_')
@section('content')

    @include('yanjin.content.editpj')
@endsection
