@extends('master.master_')
@section('content')

    @include('yanjin.pinjam.data-peminjam')
    
@endsection
