@extends('master.master-pinjem')

@section('css')
@endsection

@section('isi')
    @include('yanjin.pinjam.pinjam')
@endsection

@section('js')

@endsection
