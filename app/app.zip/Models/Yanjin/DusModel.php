<?php

namespace App\Models\Yanjin;

use Illuminate\Database\Eloquent\Model;

class DusModel extends Model
{
    protected $table = 'dus';

    protected $primaryKey = 'id';
}
