<?php

namespace App\Models\Yanjin;
use Laravel\Scout\Searchable;

use Illuminate\Database\Eloquent\Model;

class PjIzinModel extends Model
{

    use Searchable;

    protected $table = 'pj_izin';

    protected $primaryKey = 'id';

    public $timestamps = false;

    public function jenis()
    {
        return $this->belongsTo('App\Models\Yanjin\JenisIzinModel', 'jns_izin_id');
    }

}
